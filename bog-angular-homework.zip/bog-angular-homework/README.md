# Bog Angular Homework
Fix cli-app angular application



