export interface IBook {
  id?: number;
  title: string;
  shortDescription: string;
}
